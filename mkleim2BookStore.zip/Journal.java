/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookstore;

import java.util.ArrayList;

/**
 *
 * @author Matthew
 */
public class Journal extends Publication implements Citable {
    
    private int volume;
    private int number;
   
    
    public Journal(ArrayList<Author> auth, String inTitle, String inVenue, Publisher inPublisher, int volume, int number, int startingPage, int endPage, int year)
    {
        super(auth, inTitle, inVenue, inPublisher, startingPage, endPage);
        this.volume = volume;
        this.number = number;
        this.startingPage = startingPage;
        this.endPage = endPage;
        this.year = year;
    }
    

    @Override
    public String Cite() {
        return super.Cite() + String.format("%d(%d): %d - %d, %d", volume, number, startingPage, endPage, year);
    }
    
}
