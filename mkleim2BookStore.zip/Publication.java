/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookstore;

import static java.lang.Character.isUpperCase;
import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author Matthew
 */
public class Publication implements Citable, Comparable<Publication> {
    
    private ArrayList<Author> authors;
    
    private String title;
    private String venue;
    private Publisher publisher;
    
    protected int startingPage;
    protected int endPage;
    protected int year;
    
    
    public Publication(ArrayList<Author> auth, String inTitle, String inVenue, Publisher inPublisher, int start, int ending)
    {
        authors = auth;
        title = inTitle;
        venue = inVenue;
        publisher = inPublisher;
        
        Collections.sort(auth);
        
    }
    
    public void addAuthor(Author author)
    {
        authors.add(author);
    }
    
    @Override
    public String Cite() {
        String authorNames = "";
        String result = "";
        
        if(authors.size() == 1)
            authorNames += String.format("%s. %s,", authors.get(0).firstName.charAt(0), authors.get(0).lastName);
        else if(authors.size() > 1)
        {
            for(int i=0; i<authors.size()-1; i++)
            {
                authorNames += String.format("%s. %s, ", authors.get(i).firstName.charAt(0), authors.get(i).lastName);
            }
            authorNames += String.format("and %s. %s, ", authors.get(authors.size()-1).firstName.charAt(0), authors.get(authors.size()-1).lastName);
        }
        
        result += authorNames;
        
        result += "\"" + title + "\"" + ", ";
        result += venue + " (";
        
        String acronym = "";
        String[] temp = venue.split(" ");
        for(int i=0; i < temp.length; i++)
        {
            if(isUpperCase(temp[i].charAt(0)))
                acronym += temp[i].charAt(0);
        }
        
        result += acronym + "), " + publisher + ", ";
        return result;
        
        
    }

    @Override
    public int compareTo(Publication other) {
        if(authors.get(0).compareTo(other.authors.get(0)) != 0)
            return authors.get(0).compareTo(other.authors.get(0));
        else if(venue.compareTo(other.venue) != 0)
            return venue.compareTo(other.venue);
        else
            return Integer.compare(year, other.year);
    }
    
}




