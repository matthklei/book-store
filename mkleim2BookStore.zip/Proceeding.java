/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookstore;

import java.util.ArrayList;

/**
 *
 * @author Matthew
 */
public class Proceeding extends Publication implements Citable {
   
    private String city;
    
    protected int startingPage;
    protected int endPage;
    protected int year;
    
    public Proceeding(ArrayList<Author> auth, String inTitle, String inVenue, Publisher inPublisher, String city, int startingPage, int endPage, int year)
    {
        super(auth, inTitle, inVenue, inPublisher, startingPage, endPage);
        this.startingPage = startingPage;
        this.endPage = endPage;
        this.city = city;
        this.year = year;
                
    }   
    
    @Override
    public String Cite() {
        return super.Cite() + String.format("%s, %d, pp: %d - %d", city, year, startingPage, endPage);
    }
    
}
